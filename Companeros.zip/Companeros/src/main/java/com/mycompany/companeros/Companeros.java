/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.companeros;

/**
 *
 * @author DELL
 */
public class Companeros {

    public static void main(String[] args) {
        // Crear un arreglo multidimensional para almacenar los datos de los compañeros
        String[][] datosCompañeros = new String[5][4]; // 5 compañeros, 4 campos (nombre, apellido, carrera, lugar de trabajo)

        // Llenar el arreglo con los datos proporcionados
        datosCompañeros[0][0] = "Gissel"; 
        datosCompañeros[0][1] = "Veles";
        datosCompañeros[0][2] = "Ingeniero Producción";
        datosCompañeros[0][3] = "Megapaca";

        datosCompañeros[1][0] = "Jose"; 
        datosCompañeros[1][1] = "Paz";
        datosCompañeros[1][2] = "Electrónica";
        datosCompañeros[1][3] = "Diunsa";

        datosCompañeros[2][0] = "Jose"; 
        datosCompañeros[2][1] = "Alfaro";
        datosCompañeros[2][2] = "Ingeniero Producción";
        datosCompañeros[2][3] = "Megapaca";

        datosCompañeros[3][0] = "Xiomara"; 
        datosCompañeros[3][1] = "Pineda";
        datosCompañeros[3][2] = "Ingeniera en Mecatrónica";
        datosCompañeros[3][3] = "Palcasa";

        datosCompañeros[4][0] = "Yanely"; 
        datosCompañeros[4][1] = "Castillo";
        datosCompañeros[4][2] = "Gerencia de Negocios";
        datosCompañeros[4][3] = "Hondupalma";

        // Imprimir los datos de los compañeros
        System.out.println("Datos personales de los compañeros de clase:");
        for (int i = 0; i < datosCompañeros.length; i++) {
            System.out.println("Compañero " + (i + 1) + ":");
            System.out.println("Nombre: " + datosCompañeros[i][0] + " " + datosCompañeros[i][1]);
            System.out.println("Carrera: " + datosCompañeros[i][2]);
            System.out.println("Lugar de trabajo: " + datosCompañeros[i][3]);
            System.out.println(); // Línea en blanco para separar entre compañeros
        }
    }
}
     
