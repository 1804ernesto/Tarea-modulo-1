/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.numeros;

/**
 *
 * @author DELL
 */
public class Numeros {

    public static void main(String[] args) {
     
 // Usamos un ciclo for para recorrer los números del 2 al 100
        System.out.println("Los números pares del 2 al 100 son:");
        for (int i = 2; i <= 100; i += 2) {
            // Imprimir el número par
            System.out.println(i);
        }
    }
}
