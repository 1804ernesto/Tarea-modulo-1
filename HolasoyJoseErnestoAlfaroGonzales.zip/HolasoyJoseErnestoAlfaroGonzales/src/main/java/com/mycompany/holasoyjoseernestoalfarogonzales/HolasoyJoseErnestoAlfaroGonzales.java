/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.holasoyjoseernestoalfarogonzales;

/**
 *
 * @author DELL
 */
public class HolasoyJoseErnestoAlfaroGonzales {

    public static void main(String[] args) {
        System.out.println("Hola, soy Jose Ernesto Alfaro Gonzales");
    }
}
