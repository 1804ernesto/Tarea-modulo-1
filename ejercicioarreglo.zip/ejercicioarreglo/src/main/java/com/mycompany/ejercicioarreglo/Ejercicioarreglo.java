/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicioarreglo;

import java.util.Arrays;

/**
 *
 * @author DELL
 */
public class Ejercicioarreglo {

    public static void main(String[] args) {
        
      String [] nombres  = new String [10]; 
         nombres[0] = "Gissel";
        nombres[1] = "Jose";
        nombres[2] = "Josue";
        nombres[3] = "Xiomara";
        nombres[4] = "Yanely";
        nombres[5] = "Alejandro";
        nombres[6] = "Arturo";
        nombres[7] = "Elian";
        nombres[8] = "Emelyn";
        nombres[9] = "Jose";
      
      System.out.println("Los nombres de mis compañeros son:");
        for (int i = 0; i < nombres.length; i++) {
            System.out.println(nombres[i]);
        }
    }
}
        
       
 

