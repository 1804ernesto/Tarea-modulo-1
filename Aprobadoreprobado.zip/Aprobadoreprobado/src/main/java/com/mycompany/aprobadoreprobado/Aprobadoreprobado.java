/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.aprobadoreprobado;

/**
 *
 * @author DELL
 */
public class Aprobadoreprobado {

    public static void main(String[] args) {
        
       // Definir el nombre y la nota del estudiante
        String nombre = "Juan Pérez";
        double nota = 7.5;

        // Determinar el estado de aprobación
        String estado = (nota >= 6) ? "Aprobado" : "Reprobado";

        // Imprimir la información del estudiante
        System.out.println("Estudiante: " + nombre);
        System.out.println("Nota: " + nota);
        System.out.println("Estado: " + estado);
    }
}
       
