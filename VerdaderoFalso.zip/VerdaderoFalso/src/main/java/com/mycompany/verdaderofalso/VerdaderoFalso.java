/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.verdaderofalso;

/**
 *
 * @author DELL
 */
public class VerdaderoFalso {
        public static void main(String[] args) {
        // Declaración de variables
        int M = 6;
        int T = 1;
        int K = -10;

        // Expresión 1: M > T
        System.out.println("M > T: " + (M > T));

        // Expresión 2: T / K == -5
        System.out.println("T / K == -5: " + (T / K == -5));

        // Expresión 3: (M + T == 7) || (M - T == 5)
        System.out.println("(M + T == 7) || (M - T == 5): " + ((M + T == 7) || (M - T == 5)));
    }
}
        