/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.operacionesaritmeticas;

/**
 *
 * @author DELL
 */
public class OperacionesAritmeticas {

    public static void main(String[] args) {
        double numero1 = 20;
        double numero2 = 40;
        double suma,resta,multiplicacion = 0;
        double division = 0;
suma = numero1 + numero2;
resta = numero1 - numero2;
multiplicacion = numero1 * numero2;
if(numero2!=0){
    division = numero1 / numero2;
    
}
        System.out.println("la suma es:" + suma);
        System.out.println("la resta es:" + resta);
        System.out.println("la multiplicacion es:" + multiplicacion);
        System.out.println("la division es:" + division);
    }
}
